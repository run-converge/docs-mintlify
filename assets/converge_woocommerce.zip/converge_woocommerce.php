<?php
/**
 * Plugin Name: Converge
 * Description: Client-side tracking for Converge
 * Version: 0.1.0
 * Author: Converge
 * Author URI: contact@runconverge.com
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

class SettingsPage
{
    public function __construct()
    {
        if (is_admin()) {
            add_action('admin_init', [ $this, 'admin_init' ]);
            add_action('admin_menu', [ $this, 'admin_menu' ]);
        }
    }

    public function get_public_token()
    {
        $settings = get_option('converge_settings');
        return isset($settings['converge_public_token_field']) ? $settings['converge_public_token_field'] : '';
    }

    public function admin_init()
    {
        register_setting('pluginPage', 'converge_settings');

        add_settings_section(
            'converge_pluginPage_section',
            __('Settings', 'converge'),
            [ $this, 'converge_settings_section_callback' ],
            'pluginPage'
        );

        add_settings_field(
            'converge_public_token_field',
            __('Public Token', 'converge'),
            [ $this, 'converge_public_token_field_render' ],
            'pluginPage',
            'converge_pluginPage_section'
        );
    }

    public function converge_public_token_field_render()
    {
        $options = get_option('converge_settings');
        // safely get the converge_public_token_field
        $public_token = isset($options['converge_public_token_field']) ? $options['converge_public_token_field'] : '';
        ?>
    <input type='text' name='converge_settings[converge_public_token_field]' value='<?php echo __($public_token); ?>'>
    <?php
    }

    public function converge_settings_section_callback()
    {
        echo __('Configure your Converge website pixel here', 'converge');
    }

    public function converge_options_page()
    {
        ?>
    <form action='options.php' method='post'>
      <h2>Converge</h2>
      <?php
          settings_fields('pluginPage');
        do_settings_sections('pluginPage');
        submit_button();
        ?>
    </form>
    <?php
    }

    public function admin_menu()
    {
        add_submenu_page('tools.php', 'Converge', 'Converge', 'manage_options', 'converge', [ $this, 'converge_options_page' ]);
    }
}

class FirstPartyUserIDManager
{
    private $converge_first_party_cookie = '__cvg_uid';

    public function __construct()
    {
        if (! is_admin()) {
            add_action('init', [ $this, 'set_first_party_cookie' ]);
            add_action('woocommerce_store_api_checkout_update_order_meta', [ $this, 'add_cookie_value_to_order' ]);
            add_action('woocommerce_checkout_create_order', [ $this, 'add_cookie_value_to_order' ]);
        }
    }

    public function get_id()
    {
        if (! isset($_COOKIE[ $this->converge_first_party_cookie ])) {
            return null;
        }
        return sanitize_text_field($_COOKIE[ $this->converge_first_party_cookie ]);
    }

    public function set_first_party_cookie()
    {
        $cookie_value = $this->get_id();
        if (empty($cookie_value)) {
            $cookie_value = bin2hex(random_bytes(16));
        }
        // recommended maximum cookie lifetime is 400 days
        setcookie($this->converge_first_party_cookie, $cookie_value, time() + (399 * 24 * 60 * 60), "/");
    }

    public function add_cookie_value_to_order($order)
    {
        $cookie_value = $this->get_id();
        if (! empty($cookie_value)) {
            $order->update_meta_data($converge_first_party_cookie, $cookie_value);
        }
    }
}

class ViewedProductEvent
{
    public function __construct()
    {
        add_action('wp_footer', [ $this, 'handle_single_product' ]);
    }

    public function handle_single_product()
    {
        try {
            if (! (is_singular('product'))) {
                return;
            }
            global $post;
            if (! $post || ! isset($post->ID)) {
                return;
            }
            $product = wc_get_product($post->ID);
            if (!$product) {
                return;
            }

            $properties = array(
                'product_id' => $product->id,
                'name' => $product->get_title(),
                'price' => floatval($product->get_price()),
                'currency' => get_woocommerce_currency(),
                'sku' => $product->get_sku(),
            );
            ?>
            <script>
                cvg({
                    method: 'track',
                    eventName: 'Viewed Product',
                    properties: <?php echo json_encode($properties); ?>,
                });
            </script>
            <?php
        } catch (Exception $e) {
            error_log($e);
            return;
        }
    }
}

class StartedCheckoutEvent
{
    public function __construct()
    {
        add_action('wp_footer', [ $this, 'handle_checkout' ]);
    }

    public function handle_checkout()
    {
        try {
            if(is_checkout() && !is_order_received_page()):
                $cart = WC()->cart->get_cart();
                $items = array();
                $total_discount = 0;
                foreach($cart as $id => $item) {
                    $product_id = $item['variation_id'] ? $item['variation_id'] : $item['product_id'];
                    $product = new WC_Product($product_id);
                    $discount = (float) $product->get_sale_price() ? $product->get_regular_price() - $product->get_sale_price() : 0;
                    array_push($items, array(
                      'product_id' => $product->id,
                      'sku' => $product->get_sku(),
                      'name' => $product->get_title(),
                      'currency' => get_woocommerce_currency(),
                      'quantity' => $item['quantity'],
                      'price' => (float) $product->get_price(),
                      'discount' => $discount * $item['quantity'],
                    ));
                    $total_discount += $discount * $item['quantity'];
                }
                $total_discount += (float) WC()->cart->get_cart_discount_total();
                $params = array(
                  'items' => $items,
                  'total_price' => (float) WC()->cart->total,
                  'total_discount' => $total_discount,
                  'total_shipping' => (float) WC()->cart->shipping_total,
                  'currency' => get_woocommerce_currency(),
                );
                ?>
              <script>
                cvg({
                method: 'track',
                eventName: 'Started Checkout',
                properties: <?php echo json_encode($params); ?>,
                });
              </script>
              <?php
            endif;
        } catch (Exception $e) {
            error_log($e);
            return;
        }
    }
}

class AddedToCartOnCollectionPageEvent
{
    public function __construct()
    {
        add_filter('woocommerce_loop_add_to_cart_link', [ $this, 'add_product_properties_to_add_to_cart_buttons' ], 10, 2);
        add_action('woocommerce_after_add_to_cart_button', [ $this, 'cvg_woocommerce_single_add_to_cart_tracking']);
        add_action('wp_footer', [ $this, 'conversion_add_to_cart_event_ajax' ]);
    }

    public function add_product_properties_to_add_to_cart_buttons($element, $product)
    {
        try {
            // Add product data to the button as data attributes
            $attributesToAdd = array(
                'data-product-id' => $product->get_id(),
                'data-product-name' => $product->get_name(),
                'data-product-price' => $product->get_price(),
                'data-product-regular-price' => $product->get_regular_price(),
                'data-product-sale-price' => $product->get_sale_price(),
            );

            foreach ($attributesToAdd as $key => $value) {
                $element = str_replace('>', ' ' . $key . '="' . $value . '">', $element);
            }
        } catch (Exception $e) {
            error_log($e);
        }
        return $element;
    }

    public function cvg_woocommerce_single_add_to_cart_tracking()
    {
        global $product;
        if (! $product) {
            return;
        }

        $eec_product_array = array(
            'product_id' => $product->get_id(),
            'product_sku' => $product->get_sku(),
            'product_name' => $product->get_name(),
            'product_price' => $product->get_price(),
            'product_regular_price' => $product->get_regular_price(),
            'product_sale_price' => $product->get_sale_price(),
        );
        foreach ($eec_product_array as $eec_product_array_key => $eec_product_array_value) {
            echo '<input type="hidden" name="cvg_' . esc_attr($eec_product_array_key) . '" value="' . esc_attr($eec_product_array_value) . '" />' . "\n";
        }
    }

    public function conversion_add_to_cart_event_ajax()
    {
        try {
            ?>
            <script>
            try {
                jQuery(document).on('added_to_cart', function(e, f, cart_hash, button) {
                    try {
                        const _product_form = jQuery( button ).closest( 'form.cart' );
                        const product_id = button.data('product-id') || jQuery( '[name=cvg_product_id]', _product_form ).val();
                        const sku = button.data('product-sku') || jQuery( '[name=cvg_product_sku]', _product_form ).val();
                        const name = button.data('product-name') || jQuery( '[name=cvg_product_name]', _product_form ).val();
                        const product_price = button.data('product-price') || jQuery( '[name=cvg_product_price]', _product_form ).val();
                        const product_regular_price = button.data('product-regular-price') || jQuery( '[name=cvg_product_regular_price]', _product_form ).val();
                        const product_sale_price = button.data('product-sale-price') || jQuery( '[name=cvg_product_sale_price]', _product_form ).val();

                        properties = {
                            'product_id': product_id,
                            'sku': sku,
                            'name': name,
                            'currency': '<?php echo get_woocommerce_currency(); ?>',
                            'quantity': 1,
                            'price': parseFloat(product_price),
                            'discount': product_sale_price ? parseFloat(product_regular_price) - parseFloat(product_sale_price) : 0,
                        }
                        cvg({
                            method: "track",
                            eventName: "Added To Cart",
                            properties,
                        });
                    } catch (e) {
                        console.error(e);
                    }
                });
            } catch (e) {
                console.error(e);
            }
            </script>
            <?php
        } catch (Exception $e) {
            error_log($e);
        }
    }
}

class AddedToCartOnProductPageEvent
{
    public function __construct()
    {
        add_action('woocommerce_add_to_cart', [ $this, 'basic_add_to_cart_event' ], 10, 4);

        // to support product page -> cart page redirects
        add_filter('woocommerce_add_to_cart_redirect', [ $this, 'set_last_product_added_to_cart_upon_redirect' ], 10, 2);
        add_action('woocommerce_ajax_added_to_cart', [ $this, 'set_last_product_added_to_cart_upon_ajax_redirect' ]);
        add_action('woocommerce_after_cart', [ $this, 'inject_add_to_cart_after_redirect' ]);
    }

    public function basic_add_to_cart_event($cart_id, $product_id, $request_quantity, $variation_id)
    {
        // If ajax request, return early.
        if (
            (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest')
            || (
                isset($_SERVER['CONTENT_TYPE']) && (str_contains($_SERVER['CONTENT_TYPE'], 'application/json') || str_contains($_SERVER['CONTENT_TYPE'], 'application/x-www-form-urlencoded'))
            )) {
            return;
        }
        $item = $variation_id ? $variation_id : $product_id;
        $this->inject_add_to_cart_event($item, $request_quantity);
    }

    public function set_last_product_added_to_cart_upon_redirect($redirect, $product = null)
    {
        // Bail if the session variable has been set or WC()->session is null.
        if (! isset(WC()->session) || WC()->session->get('converge_last_product_added_to_cart', 0) > 0) {
            return $redirect;
        }

        $product_id = 0;

        if ($product instanceof \WC_Product) {
            $product_id = $_POST['variation_id'] ?? $product->get_id();
        } elseif (isset($_GET['add-to-cart']) && is_numeric($_GET['add-to-cart'])) {
            $product_id = $_GET['add-to-cart'];
        }

        WC()->session->set('converge_last_product_added_to_cart', (int) $product_id);

        return $redirect;
    }

    public function set_last_product_added_to_cart_upon_ajax_redirect($product_id = null)
    {
        if (! $product_id) {
            return;
        }

        $product = wc_get_product($product_id);

        if ($product instanceof \WC_Product) {
            WC()->session->set('converge_last_product_added_to_cart', $product->get_id());
        }
    }

    public function inject_add_to_cart_after_redirect()
    {
        $last_product_id = WC()->session->get('converge_last_product_added_to_cart', 0);

        if ($last_product_id > 0) {
            $this->inject_add_to_cart_event($last_product_id, 1);
            WC()->session->set('converge_last_product_added_to_cart', 0);
        }
    }

    private function inject_add_to_cart_event($product_id, $quantity)
    {
        try {
            $discount = 0;
            $product = wc_get_product($product_id);
            if ($product->get_sale_price()) {
                $discount = $product->get_regular_price() - $product->get_sale_price();
            }

            // Create the item array.
            $baseItem = array(
              'product_id' => $product_id,
              'sku' => $product->get_sku(),
              'name' => get_the_title($product_id),
              'currency' => get_woocommerce_currency(),
              'quantity' => $quantity,
              'price' => (float) $product->get_price(),
              'discount' => (float) $discount,
            );
            ?>
          <script>
            window.cvg||(c=window.cvg=function(){c.process?c.process.apply(c,arguments):c.queue.push(arguments)},c.queue=[]);
            cvg({
                method: 'track',
                eventName: 'Added To Cart',
                properties: <?php echo json_encode($baseItem, JSON_UNESCAPED_UNICODE); ?>,
            });
          </script>
          <?php
        } catch (Exception $e) {
            error_log($e);
            return;
        }
    }
}

class PlacedOrderEvent
{
    public function __construct()
    {
        add_action('woocommerce_thankyou', [ $this, 'handle_order' ]);
        add_action('woocommerce_thankyou', [ $this, 'set_aliases' ]);  // mostly legacy
    }

    public function set_aliases($order_id)
    {
        $order = wc_get_order($order_id);
        $customer_id = $order->get_customer_id();
        ?>
        <script>
            (function(){
                const orderId = "<?php echo $order_id?>";
                const customerId = "<?php echo $customer_id?>";
                const aliases = []
                if (orderId) aliases.push(`urn:woocommerce:${location.hostname}:order_id:${orderId}`)
                if (customerId && customerId !== "0") aliases.push(`urn:woocommerce:${location.hostname}:customer_id:${customerId}`)    
                cvg({
                    method: 'event',
                    event: '$identify',
                    aliases
                });
            })();
        </script>
        <?php
    }

    public function handle_order($order_id)
    {
        try {
            $order = wc_get_order($order_id);
            $items = $order->get_items();
            $products = array();
            $total_discount = 0;
            foreach ($items as $item) {
                $product = $item->get_product();
                $discount = (float) $product->get_sale_price() ? $product->get_regular_price() - $product->get_sale_price() : 0;
                $products[] = array(
                    'product_id' => $product->get_id(),
                    'sku' => $product->get_sku(),
                    'name' => $product->get_name(),
                    'currency' => get_woocommerce_currency(),
                    'quantity' => $item->get_quantity(),
                    'price' => (float) $product->get_price(),
                    'discount' => $discount
                );
                $total_discount += $discount;
            }
            $total_discount += (float) $order->get_total_discount();
            $params = array(
                'id' => (string) $order_id,
                'items' => $products,
                'total_price' => (float) $order->get_total(),
                'total_discount' => $total_discount,
                'total_shipping' => (float) $order->get_shipping_total(),
                'currency' => get_woocommerce_currency(),
            );
            // deduplicate inclusion of this script
            ?>
            <script>
                (function(){
                    // deduplicate the local Placed Order event
                    // TODO: we should perhaps make this standard in the pixel
                    const orderId = "<?php echo $order_id?>";
                    const rawOrderIds = localStorage.getItem('__cvg_order_ids')
                    const orderIds = rawOrderIds ? JSON.parse(rawOrderIds) : []
                    if (orderIds.includes(orderId)) return;
                    cvg({
                        method: 'forward',
                        eventName: 'Placed Order',
                        properties: <?php echo json_encode($params); ?>,
                        eventID: '<?php echo $order_id; ?>',
                    });
                    orderIds.push(orderId);
                    localStorage.setItem('__cvg_order_ids', JSON.stringify(orderIds));
                })();
            </script>
            <?php
        } catch (Exception $e) {
            error_log($e);
            return;
        }
    }

}

class ConvergePlugin
{
    private $settings_page;
    private $user_id_manager;
    private $viewed_product_event;

    public function __construct()
    {
        add_action('woocommerce_init', [ $this, 'setup' ]);
        $this->settings_page = new SettingsPage();
        $this->user_id_manager = new FirstPartyUserIDManager();

        $this->viewed_product_event = new ViewedProductEvent();
        $this->started_checkout_event = new StartedCheckoutEvent();
        $this->added_to_cart_on_collection_page_event = new AddedToCartOnCollectionPageEvent();
        $this->added_to_cart_on_product_page_event = new AddedToCartOnProductPageEvent();
        $this->placed_order_event = new PlacedOrderEvent();
    }

    public function setup()
    {
        add_action('wp_head', [ $this, 'add_script' ]);
    }

    public function add_script()
    {
        $public_token = $this->settings_page->get_public_token();
        if (! empty($public_token)) {
            ?>
        <!-- Start Converge Pixel Snippet -->
          <script src="https://static.runconverge.com/pixels/<?php echo __($public_token); ?>.js" async></script>
          <script>
            window.cvg||(c=window.cvg=function(){c.process?c.process.apply(c,arguments):c.queue.push(arguments)},c.queue=[]);
            cvg({method:"track",eventName:"$page_load"});
          </script>
        <!-- End Converge Pixel Snippet -->
        <?php
        }
    }
}

new ConvergePlugin();
