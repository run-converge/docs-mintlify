<?php
/**
 * Plugin Name: Converge
 * Description: Client-side tracking for Converge
 * Version: 0.1.0
 * Author: Converge
 * Author URI: contact@runconverge.com
 */

 add_action( 'admin_menu', 'converge_add_admin_menu' );
 add_action( 'admin_init', 'converge_settings_init' );
 
 
 function converge_add_admin_menu(  ) { 
 
   add_submenu_page( 'tools.php', 'Converge', 'Converge', 'manage_options', 'converge', 'converge_options_page' );
 
 }
 
 
 function converge_settings_init(  ) { 
 
   register_setting( 'pluginPage', 'converge_settings' );
 
   add_settings_section(
     'converge_pluginPage_section', 
     __( 'Settings', 'converge' ), 
     'converge_settings_section_callback', 
     'pluginPage'
   );
 
   add_settings_field( 
     'converge_public_token_field', 
     __( 'Public Token', 'converge' ), 
     'converge_public_token_field_render', 
     'pluginPage', 
     'converge_pluginPage_section' 
   );
 
 
 }
 
 
 function converge_public_token_field_render(  ) { 
 
   $options = get_option( 'converge_settings' );
   ?>
   <input type='text' name='converge_settings[converge_public_token_field]' value='<?php echo $options['converge_public_token_field']; ?>'>
   <?php
 
 }
 
 
 function converge_settings_section_callback(  ) { 
 
   echo __( 'Configure your Converge website pixel here', 'converge' );
 
 }
 
 
 function converge_options_page(  ) { 
 
     ?>
     <form action='options.php' method='post'>
 
       <h2>Converge</h2>
 
       <?php
       settings_fields( 'pluginPage' );
       do_settings_sections( 'pluginPage' );
       submit_button();
       ?>
 
     </form>
     <?php
 
 }
 

function my_console_log($data) {
  $json = json_encode($data);
  add_action('shutdown', function() use ($json) {
    echo "<script>console.log({$json})</script>";
  });
}

add_action('wp_head', 'add_script');
function add_script() {
  $publicToken = get_option('converge_settings')['converge_public_token_field'];
  try {
    ?>
    <!-- Start Converge Pixel Snippet -->
      <script src="https://static.runconverge.com/pixels/<?php echo $publicToken; ?>.js" async></script>
      <script>
        window.cvg||(c=window.cvg=function(){c.process?c.process.apply(c,arguments):c.queue.push(arguments)},c.queue=[]);
        cvg({method:"track",eventName:"$page_load"});
      </script>
    <!-- End Converge Pixel Snippet -->
    <?php

  } catch (Exception $e) {
    error_log($e);
    return;
  }
}

add_action('woocommerce_thankyou', 'converge_woocommerce_thankyou');
function converge_woocommerce_thankyou($order_id) {
  $order = wc_get_order($order_id);
  $customer_id = $order->get_customer_id();
  ?>
  <script>
    const orderId = "<?php echo $order_id?>";
    const customerId = "<?php echo $customer_id?>";
    const aliases = []
    if (orderId) aliases.push(`urn:woocommerce:${location.hostname}:order_id:${orderId}`)
    if (customerId && customerId !== "0") aliases.push(`urn:woocommerce:${location.hostname}:customer_id:${customerId}`)    
    try {
      cvg({
        method: 'event',
        event: '$identify',
        aliases
      });
    } catch (e) {
      console.error(e);
    }
  </script>
  <?php
}

add_action('wp_footer', 'handle_single_product');
function handle_single_product() {
  try {
    if (! ( is_singular( 'product' ) )) {
      return;
    }
    global $post;
    if (!isset( $post->ID )) {
      return;
    }
    $product = wc_get_product( $post->ID );
    if (!$product) {
      return;
    }
    
    $properties = array(
      'product_id' => $product->id,
      'name' => $product->get_title(),
      'price' => floatval( $product->get_price() ),
      'currency' => get_woocommerce_currency(),
      'sku' => $product->get_sku(),
    );
    ?>
    <script>
      try {
        cvg({
          method: 'event',
          event: 'Viewed Product',
          properties: <?php echo json_encode($properties); ?>,
        });
      } catch (e) {
        console.error(e);
      }
    </script>
    <?php
  } catch (Exception $e) {
    error_log($e);
    return;
  }
}

add_action('wp_footer', 'handle_checkout');
function handle_checkout() {
  try {
    if( is_checkout() && !is_order_received_page() ):
      $cart = WC()->cart->get_cart();
      $items = array();
      foreach($cart as $id => $item) {
        $product_id = $item['variation_id'] ? $item['variation_id'] : $item['product_id'];
        $product = new WC_Product( $product_id );
        array_push($items, array(
          'product_id' => $product->id,
          'sku' => $product->get_sku(),
          'name' => $product->get_title(),
          'currency' => get_woocommerce_currency(),
          'quantity' => $item['quantity'],
          'price' => (float) $product->get_price(),
          'discount' => (float) $product->get_sale_price() ? $product->get_regular_price() - $product->get_sale_price() : 0,
        ));
      }
      $params = array(
        'items' => $items,
        'total_price' => WC()->cart->total,
        'currency' => get_woocommerce_currency(),
      );
      ?>
      <script>
        try {
          cvg({
            method: 'event',
            event: 'Started Checkout',
            properties: <?php echo json_encode($params); ?>,
          });
        } catch (e) {
          console.error(e);
        }
      </script>
      <?php
    endif;
  } catch (Exception $e) {
    error_log($e);
    return;
  }
}

function inject_add_to_cart_event($product_id, $quantity) {
  try {
    $discount = 0;
    $product = wc_get_product($product_id);
    if ($product->get_sale_price()) {
      $discount = $product->get_regular_price() - $product->get_sale_price();
    }

    // Create the item array.
    $baseItem = array(
      'product_id' => $product_id,
      'sku' => $product->get_sku(),
      'name' => get_the_title($product_id),
      'currency' => get_woocommerce_currency(),
      'quantity' => $quantity,
      'price' => (float) $product->get_price(),
      'discount' => (float) $discount,
    );
    ?>
    <script>
      // Add event listener to the DOMContentLoaded event.
      try {
        document.addEventListener("DOMContentLoaded", () => {
          try {
            cvg({
              method: 'event',
              event: 'Added To Cart',
              properties: <?php echo json_encode($baseItem, JSON_UNESCAPED_UNICODE); ?>,
            });
          } catch (e) {
            console.error(e);
          }
        });
      } catch (e) {
        console.error(e);
      }
    </script>
    <?php
  } catch (Exception $e) {
    error_log($e);
    return;
  }
}

add_action('woocommerce_add_to_cart', 'conversion_add_to_cart_event', 10, 4);
function conversion_add_to_cart_event($cart_id, $product_id, $request_quantity, $variation_id)
{
  // If ajax request, return early.
  if (
      (isset($_SERVER['HTTP_X_REQUESTED_WITH']) && strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest')
      || (isset($_SERVER['CONTENT_TYPE']) && (str_contains($_SERVER['CONTENT_TYPE'], 'application/json') || str_contains($_SERVER['CONTENT_TYPE'], 'application/x-www-form-urlencoded'))
    )){
    return;
  }
  $item = $variation_id ? $variation_id : $product_id;
  inject_add_to_cart_event($item, $request_quantity);
}

add_filter('woocommerce_loop_add_to_cart_link', 'conversion_add_to_cart_button', 10, 2);
function conversion_add_to_cart_button($element, $product)
{
  try {
    // Add product data to the button as data attributes
    $attributesToAdd = array(
      'data-product-id' => $product->get_id(),
      'data-product-name' => $product->get_name(),
      'data-product-price' => $product->get_price(),
      'data-product-regular-price' => $product->get_regular_price(),
      'data-product-sale-price' => $product->get_sale_price(),
    );

    foreach ($attributesToAdd as $key => $value) {
      $element = str_replace('>', ' ' . $key . '="' . $value . '">', $element);
    }
  } catch (Exception $e) {
    error_log($e);
  }
  return $element;
}

add_action( 'woocommerce_after_add_to_cart_button', 'cvg_woocommerce_single_add_to_cart_tracking' );
function cvg_woocommerce_single_add_to_cart_tracking() {
	global $product;

  if ( ! $product ) {
		return;
	}  

  $eec_product_array = array(
    'product_id' => $product->get_id(),
    'product_sku' => $product->get_sku(),
    'product_name' => $product->get_name(),
    'product_price' => $product->get_price(),
    'product_regular_price' => $product->get_regular_price(),
    'product_sale_price' => $product->get_sale_price(),
  );

	foreach ( $eec_product_array as $eec_product_array_key => $eec_product_array_value ) {
		echo '<input type="hidden" name="cvg_' . esc_attr( $eec_product_array_key ) . '" value="' . esc_attr( $eec_product_array_value ) . '" />' . "\n";
	}
}

add_action('wp_footer', 'conversion_add_to_cart_event_ajax');
function conversion_add_to_cart_event_ajax()
{
  try {
    ?>
    <script>
      try {
        jQuery(document).on('added_to_cart', function(e, f, cart_hash, button) {
          try {
            const _product_form     = jQuery( button ).closest( 'form.cart' );
            const product_id = button.data('product-id') || jQuery( '[name=cvg_product_id]', _product_form ).val();
            const sku = button.data('product-sku') || jQuery( '[name=cvg_product_sku]', _product_form ).val();
            const name = button.data('product-name') || jQuery( '[name=cvg_product_name]', _product_form ).val();
            const product_price = button.data('product-price') || jQuery( '[name=cvg_product_price]', _product_form ).val();
            const product_regular_price = button.data('product-regular-price') || jQuery( '[name=cvg_product_regular_price]', _product_form ).val();
            const product_sale_price = button.data('product-sale-price') || jQuery( '[name=cvg_product_sale_price]', _product_form ).val();

            properties = {
                'product_id': product_id,
                'sku': sku,
                'name': name,
                'currency': '<?php echo get_woocommerce_currency(); ?>',
                'quantity': 1,
                'price': parseFloat(product_price),
                'discount': product_sale_price ? parseFloat(product_regular_price) - parseFloat(product_sale_price) : 0,
              }
              cvg({
                method: "event",
                event: "Added To Cart",
                properties,
              });
          } catch (e) {
            console.error(e);
          }
        });
      } catch (e) {
        console.error(e);
      }
    </script>
    <?php
  } catch (Exception $e) {
    error_log($e);
  }
}

// AddToCart while using redirect to cart page
add_filter( 'woocommerce_add_to_cart_redirect', 'set_last_product_added_to_cart_upon_redirect', 10, 2 );
add_action( 'woocommerce_ajax_added_to_cart', 'set_last_product_added_to_cart_upon_ajax_redirect');
add_action( 'woocommerce_after_cart', 'inject_add_to_cart_redirect_event');

function set_last_product_added_to_cart_upon_redirect( $redirect, $product = null ) {

  // Bail if the session variable has been set or WC()->session is null.
  if ( ! isset( WC()->session ) || WC()->session->get( 'converge_last_product_added_to_cart', 0 ) > 0 ) {
    return $redirect;
  }

  $product_id = 0;

  if ( $product instanceof \WC_Product ) {
    $product_id = $_POST['variation_id'] ?? $product->get_id();
  } elseif ( isset( $_GET['add-to-cart'] ) && is_numeric( $_GET['add-to-cart'] ) ) {
    $product_id = $_GET['add-to-cart'];
  }

  WC()->session->set( 'converge_last_product_added_to_cart', (int) $product_id );

  return $redirect;
}
function set_last_product_added_to_cart_upon_ajax_redirect( $product_id = null ) {

  if ( ! $product_id ) {
    return;
  }

  $product = wc_get_product( $product_id );

  if ( $product instanceof \WC_Product ) {
    WC()->session->set( 'converge_last_product_added_to_cart', $product->get_id() );
  }
}
function inject_add_to_cart_redirect_event() {
  $last_product_id = WC()->session->get( 'converge_last_product_added_to_cart', 0 );

  if ( $last_product_id > 0 ) {
    inject_add_to_cart_event( $last_product_id, 1);

    WC()->session->set( 'converge_last_product_added_to_cart', 0 );
  }
}
